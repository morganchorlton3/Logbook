name = str(input ('Hi, user please can you enter your name:'))
print('Hello '+ str.lower(name) + ' nice to meet you.')