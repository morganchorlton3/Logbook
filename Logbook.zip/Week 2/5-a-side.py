number_of_pupils = 172
number_of_pupils_in_a_team = 5

print('Number of pupils: ' , number_of_pupils)
print('Number of pupils in a Teams: ' , number_of_pupils_in_a_team)
print(' ')

number_of_teams = number_of_pupils // number_of_pupils_in_a_team
print('Number of football teams: ' , number_of_teams)

number_of_pupils_left_over = number_of_pupils % number_of_pupils_in_a_team
print('Number of pupils left over: ' , number_of_pupils_left_over)

