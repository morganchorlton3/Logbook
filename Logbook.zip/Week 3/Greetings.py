name = str(input ('Hi, user please can you enter your name:'))
print('Hello '+ name + ' nice to meet you.')